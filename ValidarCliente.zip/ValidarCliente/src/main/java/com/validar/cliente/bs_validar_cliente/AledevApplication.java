package com.validar.cliente.bs_validar_cliente;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AledevApplication {

	public static void main(String[] args) {
		SpringApplication.run(AledevApplication.class, args);
	}

}
