package com.validar.cliente.bs_validar_cliente;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AledevApplicationTests {

	@Test
	public void makeAClientrequest(){

	}

	@Test
	public void persistAClient(){

	}

	@Test
	public void fetchCanadaAttendant(){

	}

	@Test
	public void insertIntoMessageBus(){

	}
}
